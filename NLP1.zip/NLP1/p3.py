from sklearn import model_selection, preprocessing, naive_bayes, metrics
from sklearn.feature_extraction.text import TfidfVectorizer
import numpy as np
from sklearn.tree import DecisionTreeClassifier
a = np.load('text.npy').tolist()
b = np.load('label.npy').tolist()

#train_x, valid_x, train_y, valid_y = model_selection.train_test_split(trainDF['text'], trainDF['label'])
# label编码为目标变量
encoder = preprocessing.LabelEncoder()
'''tr_y = encoder.fit_transform(train_y)
va_y = encoder.fit_transform(valid_y)'''
y = encoder.fit_transform(b)
np.save('y.npy', y)
test_y = np.load('test_label.npy')
test_y = encoder.fit_transform(test_y)
# 词性级tf-idf
tfidf_chars = TfidfVectorizer(analyzer='char', ngram_range=(2, 3), max_features=5000)
tfidf_chars.fit(a)
x = tfidf_chars.transform(a)
#np.save('x.npy', x)
test_x = np.load('test_text.npy')
test_x = tfidf_chars.transform(test_x)
#np.save('test_x', test_x)
#tr_x = tfidf_chars.transform(train_x).toarray()
#va_x = tfidf_chars.transform(valid_x).toarray()

def train_model(classifier, train, label, valid, valid_y):
    classifier.fit(train, label)
    pre = classifier.predict(valid)
    ans = metrics.f1_score(valid_y, pre, average='micro')
    return ans

'''acc = train_model(naive_bayes.MultinomialNB(), x, y, test_x, test_y)
print("NB ", acc)
acc = train_model(DecisionTreeClassifier(), x, y, test_x, test_y)
print("decisiontree", acc)
acc = train_model(DecisionTreeClassifier(max_depth=50), x, y, test_x, test_y)
print("decisiontree", acc)'''
#网格搜索
best_n = 0
nacc_knn  = 0
best_m = 0
for dep in [10, 50, 100]:
    for mi_samp in [2, 5, 10, 30]:
        dct = DecisionTreeClassifier(max_depth= dep, random_state= 50, min_samples_split=mi_samp)
        dct.fit(x, y)
        acc_dct = train_model(dct, x, y, test_x, test_y)
        print('when maxdep = ',dep,' min_samples_split = ', mi_samp,' f1 score: ', acc_dct)
        if nacc_knn<acc_dct:
            nacc_knn=acc_dct
            best_n = dep
            best_m = mi_samp