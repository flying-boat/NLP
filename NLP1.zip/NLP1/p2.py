from sklearn import model_selection, preprocessing, naive_bayes, metrics
from sklearn.feature_extraction.text import TfidfVectorizer, CountVectorizer
import numpy as np
import pandas
import jieba as jb
import os

def stopwordslist(filepath):#去停用词
    stopwords = [line.strip() for line in open(filepath, 'r', encoding='utf-8').readlines()]
    return stopwords
def seg_sentence(sentence):#分词
    sentence_seged = jb.cut(sentence.strip())
    stopwords = stopwordslist(r'C:\Users\TechIts\Desktop\baidu_stopwords.txt')  #往百度里面加了符号
    outstr = ''
    for word in sentence_seged:
        word = word.lower()
        if word not in stopwords:
            if word != '\t':
                outstr += word
                outstr += " "
    return outstr
y = []
path = "C:/Users/TechIts/Desktop/fd_data/train"
trainDF = pandas.DataFrame()
texts, labels = [], []
files= os.listdir(path)
for file in files:
    n = 0
    for f in os.listdir(os.path.join(path, file)):
        if f[2]=='-':
            labels.append(f[1:2])
        else:
            labels.append(f[1:3])
        t = path+'/'+file+'/'+f
        a = open(t, 'r', encoding='GB18030', errors = 'ignore')
        sen = ''
        for line in a:
            line_seg = seg_sentence(line)
            sen+=line_seg
        texts.append(sen)
        a.close()
        n+=1

        break

trainDF['text'] = texts
trainDF['label'] = labels
# 将数据集分为训练集和验证集
train_x, valid_x, train_y, valid_y = model_selection.train_test_split(trainDF['text'], trainDF['label'])

# label编码为目标变量
encoder = preprocessing.LabelEncoder()
train_y = encoder.fit_transform(train_y)
valid_y = encoder.fit_transform(valid_y)

# 词性级tf-idf
tfidf_vect_ngram_chars = TfidfVectorizer(analyzer='char', ngram_range=(2, 3),
                                         max_features=5000)
tfidf_vect_ngram_chars.fit(trainDF['text'])
xtrain_tfidf_ngram_chars = tfidf_vect_ngram_chars.transform(train_x).toarray()
xvalid_tfidf_ngram_chars = tfidf_vect_ngram_chars.transform(valid_x)
print(type(xtrain_tfidf_ngram_chars))

def train_model(classifier, feature_vector_train, label, feature_vector_valid, is_neural_net=False):
    classifier.fit(feature_vector_train, label)
    predictions = classifier.predict(feature_vector_valid)
    if is_neural_net:
         predictions = predictions.argmax(axis=-1)
    ans = metrics.f1_score(valid_y, predictions, average='micro')
    return ans

# 特征为词性级别TF-IDF向量的朴素贝叶斯
accuracy = train_model(naive_bayes.MultinomialNB(), xtrain_tfidf_ngram_chars, train_y, xvalid_tfidf_ngram_chars)
print("NB, CharLevel Vectors: ", accuracy)
