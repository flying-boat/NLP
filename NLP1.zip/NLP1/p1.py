import numpy as np
import pandas
import jieba as jb
import os

def stopwordslist(filepath):#去停用词
    stopwords = [line.strip() for line in open(filepath, 'r', encoding='utf-8').readlines()]
    return stopwords
def seg_sentence(sentence):#分词
    sentence_seged = jb.cut(sentence.strip())
    stopwords = stopwordslist(r'C:\Users\TechIts\Desktop\baidu_stopwords.txt')  #往百度里面加了符号
    outstr = ''
    for word in sentence_seged:
        word = word.lower()
        if word not in stopwords:
            if word != '\t':
                outstr += word
                outstr += " "
    return outstr
path = "C:/Users/TechIts/Desktop/fd_data/test"
trainDF = pandas.DataFrame()
texts, labels = [], []
files= os.listdir(path)
for file in files:
    for f in os.listdir(os.path.join(path, file)):
        if f[2]=='-':
            labels.append(f[1:2])
        else:
            labels.append(f[1:3])
        t = path+'/'+file+'/'+f
        a = open(t, 'r', encoding='GB18030', errors = 'ignore')
        sen = ''
        for line in a:
            line_seg = seg_sentence(line)
            sen+=line_seg
        texts.append(sen)
        a.close()
    print(1)
np.save("test_text.npy", texts)
np.save("test_label.npy", labels)