from sklearn import  preprocessing, naive_bayes, metrics
from sklearn.feature_extraction.text import TfidfVectorizer
import numpy as np
import pandas as pd
from math import log
def calcShannonEnt(dataSet):#计算给定数据集的经验熵(香农熵)
    numEntires = len(dataSet)
    labelCounts = {}                                 #保存每个标签(Label)出现次数的字典
    for featVec in dataSet:
        currentLabel = featVec[-1]
        if currentLabel not in labelCounts.keys():
            labelCounts[currentLabel] = 0
        labelCounts[currentLabel] += 1
    shannonEnt = 0.0                                 #经验熵(香农熵)
    for key in labelCounts:
        prob = float(labelCounts[key]) / numEntires  #选择该标签(Label)的概率
        shannonEnt -= prob * log(prob, 2)            #利用公式计算
    return shannonEnt                                #返回经验熵(香农熵)

def splitDataSet(dataSet, axis, value):#函数说明:按照给定特征划分数据集
    retDataSet = []
    for featVec in dataSet:
        if featVec[axis] == value:
            reducedFeatVec = featVec[:axis]             #去掉axis特征
            reducedFeatVec.extend(featVec[axis+1:])     #将符合条件的添加到返回的数据集
            retDataSet.append(reducedFeatVec)
    return retDataSet

def chooseBestFeatureToSplit(dataSet):#函数说明:选择最优特征
    numFeatures = len(dataSet[0]) - 1                     #特征数量
    baseEntropy = calcShannonEnt(dataSet)                 #计算数据集的香农熵
    lis = []
    for i in range(numFeatures):
        #获取dataSet的第i个所有特征
        featList = [example[i] for example in dataSet]
        featList = pd.cut(featList, 20).codes
        uniqueVals = set(featList)                         #创建set集合{},元素不可重复
        newEntropy = 0.0                                   #经验条件熵
        for value in uniqueVals:
            subDataSet = splitDataSet(dataSet, i, value)           #subDataSet划分后的子集
            prob = len(subDataSet) / float(len(dataSet))
            newEntropy += prob * calcShannonEnt(subDataSet)        #根据公式计算经验条件熵
        infoGain = baseEntropy - newEntropy                        #信息增益
        lis.append(infoGain)
    return lis

label = np.load('y.npy')

test_x = np.load('test_x.npy')
test_y = np.load('test_label.npy')

encoder = preprocessing.LabelEncoder()
test_y = encoder.fit_transform(test_y)
x = np.load('x.npy')

n = 500
data = x.tolist()
bestfeature=chooseBestFeatureToSplit(data)
m = sorted(bestfeature, reverse = True)
lis_shan = []    #信息增益选出的特征
for i in range(n):
    for j in range(len(bestfeature)):
        if m[i]==bestfeature[j]:
                lis_shan.append(j)
                bestfeature[j] = -1
                break
data = x.T.tolist()
test_data = test_x.T.tolist()
ans = []
test_ans = []
for i in lis_shan:
    ans.append(data[i])
    test_ans.append(test_data[i])
ans = np.array(ans)
ans = ans.T#最终的训练集x
test_ans = np.array(test_ans).T#最终的测试集x
def train_model(classifier, train, label, valid, valid_y):
    classifier.fit(train, label)
    pre = classifier.predict(valid)
    ans = metrics.f1_score(valid_y, pre, average='micro')
    return ans

acc = train_model(naive_bayes.MultinomialNB(), ans, label, test_ans, test_y)
print("NB ", acc)